# File: benchmarks/benchmark_solver.jl

"""
    add_solver_benchmarks!(suite, backend; T=Float32, particle_counts=[10_000, 50_000])

Register the solver benchmarks in `suite["solver"]`: the isolated G2P2G kernel and
a full time step for every combination of grid type and material. All grid types
run the same two kernels (`g2p2g_pass1_kernel!`, `g2p2g_pass2_kernel!`), specialized per grid access type. On the CPU
the device function is additionally run in a serial loop to check it for allocations.
"""
function add_solver_benchmarks!(
    suite::BenchmarkGroup,
    backend::Backend;
    T::Type{<:AbstractFloat}=Float32,
    particle_counts::Vector{Int}=[10_000, 50_000],
)
    grp = suite["solver"] = BenchmarkGroup()

    mat_simple = NeoHookean(ρ=T(1000.0), E=T(1e6), ν=T(0.3))
    mat_solid  = Basalt(T; eos=:tillotson, elasticity=:hypoelastic, viscosity=BulkViscosity{T}())
    gravity    = ConstantGravity(SVector{3, T}(0.0, -9.81, 0.0))
    noslip     = NoSlipBoundary()

    grid_configs = (
        # label              grid type   domain        boundary condition
        ("DenseGrid",        DenseGrid,  AutoDomain(), noslip),
        ("SparseGrid_Open",  SparseGrid, OpenDomain(), NullBoundaryCondition()),
        ("SparseGrid_Box",   SparseGrid, FittedBox(),  noslip),
    )
    materials = (("NeoHookean", mat_simple), ("Basalt_Tillotson", mat_solid))

    for n_target in particle_counts
        sub = grp["N_$(n_target)"] = BenchmarkGroup()

        for (grid_label, grid_type, domain, bc) in grid_configs, (mat_label, mat) in materials
            model, _ = build_benchmark_model(
                n_target, backend;
                T=T,
                grid_type=grid_type,
                domain=domain,
                material=mat,
                boundary_condition=bc,
                external_force=gravity,
            )
            backup  = capture_particle_backup(model)
            dt_tiny = T(1e-7)       # particles hardly move, so the active tiles stay valid between restores

            case = sub["$(grid_label)_$(mat_label)"] = BenchmarkGroup()

            # isolated G2P2G kernel
            case["g2p2g!"] = @benchmarkable(
                g2p2g!($model, $dt_tiny),
                setup = (restore_particles!($model, $backup))
            )

            # full time step: CFL + G2P2G + forces + BCs + grid reset / tile activation
            case["step!"] = @benchmarkable(
                step!($model),
                setup = (restore_particles!($model, $backup))
            )

            # CFL reduction over the particle wave speeds (read only, no restore needed)
            case["max_wavespeed"] = @benchmarkable(
                sync_run!(SmashMPM.max_wavespeed, $backend, $model)
            )
            # Kernel launches allocate on every backend, so g2p2g!/step! are not checked.
            # max_wavespeed is a plain `maximum` on the CPU.
            is_cpu(backend) && expect_no_allocs!(case, "max_wavespeed")

            # Same work as g2p2g!, but the device function in a serial host loop
            # (no kernel launch): must be allocation-free, so the unified kernel and
            # the grid access layer are checked for every grid type and material.
            # Single-threaded, so compare its time only with itself (baseline), not with g2p2g!.
            if is_cpu(backend)
                case["g2p2g pass 1+2 (serial)"] = @benchmarkable(
                    g2p2g_serial!($model, $dt_tiny),
                    setup = (restore_particles!($model, $backup))
                )
                expect_no_allocs!(case, "g2p2g pass 1+2 (serial)")
            end
        end
    end

    return grp
end
